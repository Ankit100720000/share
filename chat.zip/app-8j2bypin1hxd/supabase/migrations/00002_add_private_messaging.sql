-- Add receiver_id column to messages table for private messaging
ALTER TABLE public.messages 
ADD COLUMN receiver_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Create index for better query performance
CREATE INDEX idx_messages_receiver_id ON public.messages(receiver_id);
CREATE INDEX idx_messages_conversation ON public.messages(sender_id, receiver_id);

-- Drop old policies
DROP POLICY IF EXISTS "Admins have full access to messages" ON public.messages;
DROP POLICY IF EXISTS "Users can view all messages" ON public.messages;
DROP POLICY IF EXISTS "Users can insert their own messages" ON public.messages;
DROP POLICY IF EXISTS "Users can delete their own messages" ON public.messages;

-- Create new policies for private messaging
CREATE POLICY "Admins have full access to messages" ON public.messages
  FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view their own messages" ON public.messages
  FOR SELECT TO authenticated USING (
    auth.uid() = sender_id OR auth.uid() = receiver_id
  );

CREATE POLICY "Users can insert messages to others" ON public.messages
  FOR INSERT TO authenticated WITH CHECK (
    auth.uid() = sender_id AND receiver_id IS NOT NULL
  );

CREATE POLICY "Users can delete their own sent messages" ON public.messages
  FOR DELETE TO authenticated USING (auth.uid() = sender_id);