import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { messageApi, profileApi, storageApi, messageFileApi } from '@/db/api';
import type { Message, Profile } from '@/types';
import { UserList } from '@/components/chat/UserList';
import { ChatArea } from '@/components/chat/ChatArea';
import { MessageInput } from '@/components/chat/MessageInput';
import { UserInfoPanel } from '@/components/chat/UserInfoPanel';
import { useToast } from '@/hooks/use-toast';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Menu, Users, Info, MessageSquare } from 'lucide-react';

export default function Chat() {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [showUserList, setShowUserList] = useState(false);
  const [showUserInfo, setShowUserInfo] = useState(false);
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadMessages = async () => {
    if (!profile || !selectedUser) {
      setMessages([]);
      return;
    }
    const fetchedMessages = await messageApi.getConversation(profile.id, selectedUser.id, 100);
    setMessages(fetchedMessages);
    setTimeout(scrollToBottom, 100);
  };

  const loadUsers = async () => {
    const fetchedUsers = await profileApi.getAllProfiles();
    setUsers(fetchedUsers.filter(u => u.id !== profile?.id));
  };

  useEffect(() => {
    const initialize = async () => {
      setIsLoading(true);
      await loadUsers();
      setIsLoading(false);
    };

    initialize();

    const userInterval = setInterval(loadUsers, 5000);

    return () => {
      clearInterval(userInterval);
    };
  }, [profile?.id]);

  useEffect(() => {
    if (selectedUser && profile) {
      loadMessages();
      const messageInterval = setInterval(loadMessages, 3000);
      return () => clearInterval(messageInterval);
    }
  }, [selectedUser?.id, profile?.id]);

  const handleSendMessage = async (content: string, files: File[]) => {
    if (!profile || !selectedUser || isSending) return;

    setIsSending(true);

    try {
      const message = await messageApi.sendMessage(profile.id, selectedUser.id, content);
      
      if (!message) {
        throw new Error('Failed to send message');
      }

      if (files.length > 0) {
        for (const file of files) {
          const fileUrl = await storageApi.uploadFile(file, profile.id);
          
          if (fileUrl) {
            await messageFileApi.addMessageFile(message.id, {
              message_id: message.id,
              file_url: fileUrl,
              file_name: file.name,
              file_type: file.type,
              file_size: file.size,
            });
          }
        }
      }

      await loadMessages();
      
      toast({
        title: 'Message Sent',
        description: 'Your message has been delivered.',
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleSelectUser = (user: Profile) => {
    setSelectedUser(user);
    setShowUserList(false);
    setMessages([]);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-57px)]">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading chat...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-57px)] bg-background overflow-hidden">
      {/* Mobile User List Sheet */}
      <Sheet open={showUserList} onOpenChange={setShowUserList}>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="xl:hidden fixed bottom-20 left-4 z-40 h-12 w-12 rounded-full shadow-lg bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-80">
          <UserList 
            users={users} 
            selectedUser={selectedUser} 
            onSelectUser={handleSelectUser}
            currentUserId={profile?.id}
          />
        </SheetContent>
      </Sheet>

      {/* Desktop User List */}
      <div className="hidden xl:block">
        <UserList 
          users={users} 
          selectedUser={selectedUser} 
          onSelectUser={handleSelectUser}
          currentUserId={profile?.id}
        />
      </div>
      
      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <div className="xl:hidden flex items-center justify-between p-3 border-b border-border bg-card">
          {selectedUser ? (
            <>
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10">
                  <span className="text-xs font-semibold text-primary">
                    {selectedUser.username.substring(0, 2).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h2 className="font-semibold text-sm">{selectedUser.username}</h2>
                  <p className="text-xs text-muted-foreground">
                    {selectedUser.is_online ? '🟢 Online' : 'Offline'}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowUserInfo(true)}
              >
                <Info className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <h2 className="font-semibold text-sm">Select a User</h2>
                <p className="text-xs text-muted-foreground">
                  {users.filter(u => u.is_online).length} online
                </p>
              </div>
            </div>
          )}
        </div>

        {selectedUser ? (
          <>
            <ChatArea 
              messages={messages} 
              currentUserId={profile?.id || ''}
              messagesEndRef={messagesEndRef}
              selectedUser={selectedUser}
            />
            <MessageInput 
              onSendMessage={handleSendMessage} 
              disabled={isSending}
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gradient-to-b from-secondary/30 to-secondary">
            <div className="text-center space-y-4 p-6">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <MessageSquare className="w-10 h-10 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Welcome to ChatHub</h3>
                <p className="text-muted-foreground">
                  Select a user from the list to start chatting
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Mobile User Info Sheet */}
      <Sheet open={showUserInfo} onOpenChange={setShowUserInfo}>
        <SheetContent side="right" className="p-0 w-80">
          <UserInfoPanel 
            user={selectedUser} 
            onClose={() => setShowUserInfo(false)}
          />
        </SheetContent>
      </Sheet>

      {/* Desktop User Info Panel */}
      <div className="hidden xl:block">
        <UserInfoPanel 
          user={selectedUser} 
          onClose={() => setSelectedUser(null)}
        />
      </div>
    </div>
  );
}
