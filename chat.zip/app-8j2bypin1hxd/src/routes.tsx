import Chat from './pages/Chat';
import Login from './pages/Login';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Chat',
    path: '/',
    element: <Chat />
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />
  }
];

export default routes;
