import { supabase } from './supabase';
import type { Profile, Message, MessageFile } from '@/types';

// Profile API
export const profileApi = {
  async getCurrentProfile(): Promise<Profile | null> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching current profile:', error);
      return null;
    }
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('username', { ascending: true });

    if (error) {
      console.error('Error fetching profiles:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async updateProfile(id: string, updates: Partial<Profile>): Promise<boolean> {
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', id);

    if (error) {
      console.error('Error updating profile:', error);
      return false;
    }
    return true;
  },

  async updateOnlineStatus(id: string, isOnline: boolean): Promise<boolean> {
    const { error } = await supabase
      .from('profiles')
      .update({ 
        is_online: isOnline,
        last_seen: new Date().toISOString()
      })
      .eq('id', id);

    if (error) {
      console.error('Error updating online status:', error);
      return false;
    }
    return true;
  },

  async getProfileById(id: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching profile:', error);
      return null;
    }
    return data;
  }
};

// Message API
export const messageApi = {
  async getConversation(userId1: string, userId2: string, limit = 100): Promise<Message[]> {
    const { data, error } = await supabase
      .from('messages')
      .select(`
        *,
        sender:profiles!sender_id(*),
        receiver:profiles!receiver_id(*),
        files:message_files(*)
      `)
      .or(`and(sender_id.eq.${userId1},receiver_id.eq.${userId2}),and(sender_id.eq.${userId2},receiver_id.eq.${userId1})`)
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) {
      console.error('Error fetching conversation:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async sendMessage(senderId: string, receiverId: string, content: string): Promise<Message | null> {
    const { data, error } = await supabase
      .from('messages')
      .insert({ sender_id: senderId, receiver_id: receiverId, content })
      .select(`
        *,
        sender:profiles!sender_id(*),
        receiver:profiles!receiver_id(*),
        files:message_files(*)
      `)
      .maybeSingle();

    if (error) {
      console.error('Error sending message:', error);
      return null;
    }
    return data;
  },

  async deleteMessage(messageId: string): Promise<boolean> {
    const { error } = await supabase
      .from('messages')
      .delete()
      .eq('id', messageId);

    if (error) {
      console.error('Error deleting message:', error);
      return false;
    }
    return true;
  },

  async getRecentConversations(userId: string): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('messages')
      .select('sender_id, receiver_id')
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Error fetching recent conversations:', error);
      return [];
    }

    const userIds = new Set<string>();
    data?.forEach((msg) => {
      if (msg.sender_id !== userId) userIds.add(msg.sender_id);
      if (msg.receiver_id !== userId) userIds.add(msg.receiver_id);
    });

    if (userIds.size === 0) return [];

    const { data: profiles, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .in('id', Array.from(userIds));

    if (profileError) {
      console.error('Error fetching conversation profiles:', profileError);
      return [];
    }

    return Array.isArray(profiles) ? profiles : [];
  }
};

// Message File API
export const messageFileApi = {
  async addMessageFile(messageId: string, fileData: Omit<MessageFile, 'id' | 'created_at'>): Promise<MessageFile | null> {
    const { data, error } = await supabase
      .from('message_files')
      .insert(fileData)
      .select('*')
      .maybeSingle();

    if (error) {
      console.error('Error adding message file:', error);
      return null;
    }
    return data;
  },

  async deleteMessageFile(fileId: string): Promise<boolean> {
    const { error } = await supabase
      .from('message_files')
      .delete()
      .eq('id', fileId);

    if (error) {
      console.error('Error deleting message file:', error);
      return false;
    }
    return true;
  }
};

// Storage API
export const storageApi = {
  async uploadFile(file: File, userId: string): Promise<string | null> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;

    const { data, error } = await supabase.storage
      .from('app-8j2bypin1hxd_chat_files')
      .upload(fileName, file);

    if (error) {
      console.error('Error uploading file:', error);
      return null;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('app-8j2bypin1hxd_chat_files')
      .getPublicUrl(data.path);

    return publicUrl;
  },

  async deleteFile(filePath: string): Promise<boolean> {
    const { error } = await supabase.storage
      .from('app-8j2bypin1hxd_chat_files')
      .remove([filePath]);

    if (error) {
      console.error('Error deleting file:', error);
      return false;
    }
    return true;
  }
};
