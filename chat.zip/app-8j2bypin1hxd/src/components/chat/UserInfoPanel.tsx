import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { X, Users } from 'lucide-react';
import type { Profile } from '@/types';
import { cn } from '@/lib/utils';

interface UserInfoPanelProps {
  user: Profile | null;
  onClose: () => void;
}

export function UserInfoPanel({ user, onClose }: UserInfoPanelProps) {
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatLastSeen = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    return formatDate(timestamp);
  };

  return (
    <div
      className={cn(
        'w-full xl:w-80 border-l border-border bg-card transition-all duration-300 h-full',
        user ? 'translate-x-0' : 'translate-x-full hidden xl:block'
      )}
    >
      {user ? (
        <div className="flex flex-col h-full animate-fade-in">
          <div className="p-4 border-b border-border flex items-center justify-between bg-gradient-to-r from-primary/5 to-accent/5">
            <h2 className="text-lg font-semibold">User Info</h2>
            <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-destructive/10 hover:text-destructive">
              <X className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex-1 p-6 space-y-6 overflow-y-auto">
            <div className="flex flex-col items-center">
              <div className="relative mb-4">
                <Avatar className="h-24 w-24 ring-4 ring-primary/20 shadow-lg">
                  <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground text-2xl font-bold">
                    {getInitials(user.username)}
                  </AvatarFallback>
                </Avatar>
                {user.is_online && (
                  <div className="absolute bottom-2 right-2 h-5 w-5 bg-accent border-4 border-card rounded-full animate-pulse shadow-lg" />
                )}
              </div>

              <h3 className="text-xl font-semibold text-center mb-2">
                {user.username}
              </h3>

              <div className="flex gap-2 mb-4">
                <Badge variant={user.is_online ? 'default' : 'secondary'} className="shadow-sm">
                  {user.is_online ? '🟢 Online' : '⚫ Offline'}
                </Badge>
                {user.role === 'admin' && (
                  <Badge variant="secondary" className="shadow-sm">
                    👑 Admin
                  </Badge>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Status
                </p>
                <p className="text-sm font-medium">
                  {user.is_online ? '🟢 Active now' : `Last seen ${formatLastSeen(user.last_seen)}`}
                </p>
              </div>

              <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Member Since
                </p>
                <p className="text-sm font-medium">{formatDate(user.created_at)}</p>
              </div>

              {user.email && (
                <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                    Email
                  </p>
                  <p className="text-sm font-medium break-all">{user.email}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-full p-6 text-center">
          <div className="space-y-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Users className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">No User Selected</h3>
              <p className="text-sm text-muted-foreground">
                Select a user from the list to view their information
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
