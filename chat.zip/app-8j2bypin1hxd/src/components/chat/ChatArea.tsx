import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import type { Message, Profile } from '@/types';
import { cn } from '@/lib/utils';
import { Download, FileIcon, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ChatAreaProps {
  messages: Message[];
  currentUserId: string;
  messagesEndRef: React.RefObject<HTMLDivElement>;
  selectedUser?: Profile | null;
}

export function ChatArea({ messages, currentUserId, messagesEndRef, selectedUser }: ChatAreaProps) {
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const isImageFile = (fileType: string) => {
    return fileType.startsWith('image/');
  };

  const handleDownload = (fileUrl: string, fileName: string) => {
    const link = document.createElement('a');
    link.href = fileUrl;
    link.download = fileName;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 flex flex-col bg-gradient-to-b from-secondary/30 to-secondary">
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4 max-w-4xl mx-auto">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full py-12 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <MessageSquare className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No messages yet</h3>
              <p className="text-muted-foreground text-sm">
                {selectedUser 
                  ? `Start a conversation with ${selectedUser.username}`
                  : 'Start the conversation by sending a message below'
                }
              </p>
            </div>
          )}

          {messages.map((message) => {
            const isOwnMessage = message.sender_id === currentUserId;
            
            return (
              <div
                key={message.id}
                className={cn(
                  'flex gap-3 animate-slide-up',
                  isOwnMessage ? 'flex-row-reverse' : 'flex-row'
                )}
              >
                <Avatar className="h-8 w-8 shrink-0 ring-2 ring-background">
                  <AvatarFallback className={cn(
                    "text-xs font-semibold",
                    isOwnMessage 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-accent text-accent-foreground"
                  )}>
                    {getInitials(message.sender?.username || 'U')}
                  </AvatarFallback>
                </Avatar>

                <div
                  className={cn(
                    'flex flex-col gap-1 max-w-[85%] xl:max-w-[70%]',
                    isOwnMessage ? 'items-end' : 'items-start'
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">
                      {message.sender?.username || 'Unknown'}
                    </span>
                    {message.sender?.role === 'admin' && (
                      <Badge variant="secondary" className="text-xs">
                        Admin
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {formatTime(message.created_at)}
                    </span>
                  </div>

                  <div
                    className={cn(
                      'rounded-2xl px-4 py-2 break-words shadow-sm',
                      isOwnMessage
                        ? 'bg-primary text-primary-foreground rounded-tr-sm'
                        : 'bg-card border border-border rounded-tl-sm'
                    )}
                  >
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                  </div>

                  {message.files && message.files.length > 0 && (
                    <div className="space-y-2 w-full">
                      {message.files.map((file) => (
                        <div key={file.id} className="animate-fade-in">
                          {isImageFile(file.file_type) ? (
                            <div className="rounded-xl overflow-hidden border-2 border-border shadow-md hover:shadow-lg transition-shadow">
                              <img
                                src={file.file_url}
                                alt={file.file_name}
                                className="max-w-full h-auto max-h-64 object-contain bg-card"
                                loading="lazy"
                              />
                            </div>
                          ) : (
                            <div className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border shadow-sm hover:shadow-md transition-all">
                              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10">
                                <FileIcon className="h-5 w-5 text-primary" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">
                                  {file.file_name}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {formatFileSize(file.file_size)}
                                </p>
                              </div>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="shrink-0 hover:bg-primary/10"
                                onClick={() => handleDownload(file.file_url, file.file_name)}
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
    </div>
  );
}
