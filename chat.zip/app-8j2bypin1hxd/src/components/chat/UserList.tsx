import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import type { Profile } from '@/types';
import { cn } from '@/lib/utils';
import { Users } from 'lucide-react';

interface UserListProps {
  users: Profile[];
  selectedUser: Profile | null;
  onSelectUser: (user: Profile) => void;
  currentUserId?: string;
}

export function UserList({ users, selectedUser, onSelectUser, currentUserId }: UserListProps) {
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  const onlineUsers = users.filter(u => u.is_online);
  const offlineUsers = users.filter(u => !u.is_online);

  return (
    <div className="w-full xl:w-80 border-r border-border bg-card flex flex-col h-full">
      <div className="p-4 border-b border-border bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="flex items-center gap-2 mb-2">
          <Users className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Users</h2>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-full bg-accent" />
            <span className="text-muted-foreground">
              {onlineUsers.length} online
            </span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-full bg-muted" />
            <span className="text-muted-foreground">
              {offlineUsers.length} offline
            </span>
          </div>
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {onlineUsers.length > 0 && (
            <div className="px-3 py-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Online
              </p>
            </div>
          )}
          
          {onlineUsers.map((user) => (
            <button
              key={user.id}
              onClick={() => onSelectUser(user)}
              className={cn(
                'w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200',
                'hover:bg-accent/50 hover:shadow-sm',
                selectedUser?.id === user.id && 'bg-accent shadow-sm',
                user.id === currentUserId && 'opacity-75'
              )}
            >
              <div className="relative">
                <Avatar className="h-10 w-10 ring-2 ring-primary/20">
                  <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground font-semibold">
                    {getInitials(user.username)}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute bottom-0 right-0 h-3 w-3 bg-accent border-2 border-card rounded-full animate-pulse" />
              </div>
              
              <div className="flex-1 text-left min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium truncate">
                    {user.username}
                    {user.id === currentUserId && ' (You)'}
                  </p>
                  {user.role === 'admin' && (
                    <Badge variant="secondary" className="text-xs">
                      Admin
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-accent font-medium">
                  Active now
                </p>
              </div>
            </button>
          ))}

          {offlineUsers.length > 0 && (
            <div className="px-3 py-2 mt-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Offline
              </p>
            </div>
          )}

          {offlineUsers.map((user) => (
            <button
              key={user.id}
              onClick={() => onSelectUser(user)}
              className={cn(
                'w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200',
                'hover:bg-accent/30',
                selectedUser?.id === user.id && 'bg-accent/30',
                user.id === currentUserId && 'opacity-75'
              )}
            >
              <div className="relative">
                <Avatar className="h-10 w-10 opacity-75">
                  <AvatarFallback className="bg-muted text-muted-foreground font-semibold">
                    {getInitials(user.username)}
                  </AvatarFallback>
                </Avatar>
              </div>
              
              <div className="flex-1 text-left min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium truncate text-muted-foreground">
                    {user.username}
                    {user.id === currentUserId && ' (You)'}
                  </p>
                  {user.role === 'admin' && (
                    <Badge variant="secondary" className="text-xs opacity-75">
                      Admin
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Offline
                </p>
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
