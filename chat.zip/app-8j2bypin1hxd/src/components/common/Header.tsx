import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { LogOut, User, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function Header() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <header className="border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 sticky top-0 z-50 shadow-sm">
      <div className="flex items-center justify-between px-4 xl:px-6 py-3">
        <div className="flex items-center gap-2 xl:gap-3">
          <div className="flex items-center justify-center w-8 h-8 xl:w-10 xl:h-10 rounded-lg bg-primary/10">
            <MessageSquare className="w-4 h-4 xl:w-5 xl:h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg xl:text-2xl font-bold text-primary">ChatHub</h1>
            <p className="hidden xl:block text-xs text-muted-foreground">Real-Time Messaging</p>
          </div>
        </div>

        {profile && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 h-auto py-2 px-2 xl:px-3 hover:bg-accent/50 transition-colors">
                <Avatar className="h-8 w-8 xl:h-9 xl:w-9 ring-2 ring-primary/20">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xs xl:text-sm font-semibold">
                    {getInitials(profile.username)}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden xl:flex flex-col items-start">
                  <span className="font-medium text-sm">{profile.username}</span>
                  <div className="flex items-center gap-1">
                    <div className={`h-2 w-2 rounded-full ${profile.is_online ? 'bg-accent' : 'bg-muted'}`} />
                    <span className="text-xs text-muted-foreground">
                      {profile.is_online ? 'Online' : 'Offline'}
                    </span>
                  </div>
                </div>
                {profile.role === 'admin' && (
                  <Badge variant="secondary" className="hidden xl:inline-flex text-xs">
                    Admin
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 animate-scale-in">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem disabled>
                <User className="mr-2 h-4 w-4" />
                <span>{profile.username}</span>
              </DropdownMenuItem>
              {profile.role === 'admin' && (
                <DropdownMenuItem disabled>
                  <Badge variant="secondary" className="text-xs">
                    Admin
                  </Badge>
                </DropdownMenuItem>
              )}
              <DropdownMenuItem disabled>
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${profile.is_online ? 'bg-accent' : 'bg-muted'}`} />
                  <span>{profile.is_online ? 'Online' : 'Offline'}</span>
                </div>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log Out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </header>
  );
}
