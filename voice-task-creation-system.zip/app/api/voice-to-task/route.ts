import { type NextRequest, NextResponse } from "next/server"

interface VoiceRequest {
  voice_text: string
  source_language?: string
  priority?: "low" | "medium" | "high"
}

interface Task {
  id: number
  title: string
  description: string
  priority: string
  status: string
  created_at: string
}

// Mock database storage (in production, use real database)
const tasks: Task[] = [
  {
    id: 1,
    title: "Example Task",
    description: "This is an example task created from voice",
    priority: "medium",
    status: "pending",
    created_at: new Date().toISOString(),
  },
]

export async function POST(request: NextRequest) {
  try {
    const body: VoiceRequest = await request.json()
    const { voice_text, source_language = "en", priority = "medium" } = body

    if (!voice_text || voice_text.trim().length === 0) {
      return NextResponse.json({ error: "Voice text is required" }, { status: 400 })
    }

    const taskTitle = voice_text.substring(0, 100)
    const taskDescription = voice_text

    // Create task
    const taskId = Math.max(...tasks.map((t) => t.id), 0) + 1
    const newTask: Task = {
      id: taskId,
      title: taskTitle,
      description: taskDescription,
      priority,
      status: "pending",
      created_at: new Date().toISOString(),
    }

    tasks.push(newTask)

    return NextResponse.json(
      {
        success: true,
        message: "Task created successfully",
        task_id: taskId,
        priority: priority,
      },
      { status: 201 },
    )
  } catch (error: any) {
    console.error("Error in voice-to-task:", error)
    return NextResponse.json({ error: error.message || "Failed to process task" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json(tasks)
}
