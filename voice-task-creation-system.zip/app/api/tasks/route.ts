import { type NextRequest, NextResponse } from "next/server"

interface Task {
  id: number
  title: string
  description: string
  priority: string
  status: string
  created_at: string
}

// Mock database storage (in production, use real database)
const tasks: Task[] = [
  {
    id: 1,
    title: "Example Task",
    description: "This is an example task created from voice",
    priority: "medium",
    status: "pending",
    created_at: new Date().toISOString(),
  },
]

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json({
      success: true,
      count: tasks.length,
      tasks: tasks.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()),
    })
  } catch (error: any) {
    return NextResponse.json({ error: "Failed to fetch tasks", message: error.message }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description = "", priority = "medium", due_date = null } = body

    if (!title || title.trim().length === 0) {
      return NextResponse.json({ error: "Task title is required" }, { status: 400 })
    }

    const taskId = Math.max(...tasks.map((t) => t.id), 0) + 1
    const newTask: Task = {
      id: taskId,
      title: title.trim(),
      description,
      priority,
      status: "pending",
      created_at: new Date().toISOString(),
    }

    tasks.push(newTask)

    return NextResponse.json(
      {
        success: true,
        message: "Task created successfully",
        task_id: taskId,
        task: newTask,
      },
      { status: 201 },
    )
  } catch (error: any) {
    return NextResponse.json({ error: "Failed to create task", message: error.message }, { status: 500 })
  }
}
