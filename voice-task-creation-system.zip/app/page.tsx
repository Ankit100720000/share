"use client"

import { useState } from "react"
import TaskForm from "@/components/task-form"
import TaskList from "@/components/task-list"

export default function Home() {
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  const handleTaskCreated = () => {
    setRefreshTrigger((prev) => prev + 1)
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto">
        <div className="pt-8">
          <TaskForm onTaskCreated={handleTaskCreated} />
        </div>
        <TaskList refreshTrigger={refreshTrigger} />
      </div>
    </main>
  )
}
