"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mic } from "lucide-react"

interface VoiceInputProps {
  value: string
  onChange: (value: string) => void
  isLoading?: boolean
}

export default function VoiceInput({ value, onChange, isLoading = false }: VoiceInputProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [language, setLanguage] = useState("en-US")
  const recognitionRef = useRef<any>(null)
  const [error, setError] = useState("")

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = language

      recognitionRef.current.onstart = () => {
        setIsRecording(true)
        setError("")
      }

      recognitionRef.current.onresult = (event: any) => {
        let transcript = ""
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript
        }
        onChange(value + (value ? " " : "") + transcript)
      }

      recognitionRef.current.onerror = (event: any) => {
        setError(`Error: ${event.error}`)
        setIsRecording(false)
      }

      recognitionRef.current.onend = () => {
        setIsRecording(false)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
    }
  }, [language, value, onChange])

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      setError("Web Speech API not supported")
      return
    }

    if (isRecording) {
      recognitionRef.current.stop()
    } else {
      recognitionRef.current.start()
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          disabled={isRecording || isLoading}
          className="px-3 py-2 border border-input rounded-md text-sm bg-background"
        >
          <option value="en-US">English</option>
          <option value="hi-IN">Hindi</option>
        </select>

        <Button
          onClick={toggleRecording}
          disabled={isLoading}
          variant={isRecording ? "destructive" : "outline"}
          size="sm"
          className="gap-2"
        >
          <Mic className="w-4 h-4" />
          {isRecording ? "Stop" : "Voice"}
        </Button>
      </div>

      <Input
        placeholder="Your task description (type or use voice button)"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={isLoading}
        className="w-full"
      />

      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  )
}
