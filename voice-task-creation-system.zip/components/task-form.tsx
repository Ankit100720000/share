"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import VoiceInput from "./voice-input"

interface TaskFormProps {
  onTaskCreated?: () => void
}

export default function TaskForm({ onTaskCreated }: TaskFormProps) {
  const [taskDescription, setTaskDescription] = useState("")
  const [priority, setPriority] = useState("medium")
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error" | "">("")

  const handleSubmit = async () => {
    if (!taskDescription.trim()) {
      setMessage("Please enter a task description")
      setMessageType("error")
      return
    }

    setIsLoading(true)
    setMessage("")

    try {
      const response = await fetch("/api/voice-to-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voice_text: taskDescription,
          source_language: "en",
          priority: priority,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create task")
      }

      setMessage("Task created successfully!")
      setMessageType("success")
      setTaskDescription("")
      setPriority("medium")

      if (onTaskCreated) {
        onTaskCreated()
      }

      setTimeout(() => setMessage(""), 3000)
    } catch (error: any) {
      setMessage(`Error: ${error.message}`)
      setMessageType("error")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center px-4 py-8">
      <Card className="w-full max-w-md p-6 shadow-lg">
        <h1 className="text-2xl font-bold mb-6">Create Task</h1>

        <VoiceInput value={taskDescription} onChange={setTaskDescription} isLoading={isLoading} />

        <div className="mt-4 mb-4">
          <label htmlFor="priority" className="block text-sm font-semibold mb-2">
            Priority
          </label>
          <select
            id="priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            disabled={isLoading}
            className="w-full px-3 py-2 border border-input rounded-md text-sm bg-background"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>

        <Button onClick={handleSubmit} disabled={isLoading || !taskDescription.trim()} className="w-full">
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Creating...
            </>
          ) : (
            "Create Task"
          )}
        </Button>

        {message && (
          <div
            className={`mt-4 p-3 rounded text-sm ${
              messageType === "success" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            }`}
          >
            {message}
          </div>
        )}
      </Card>
    </div>
  )
}
