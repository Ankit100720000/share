"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Mic, Square, Loader2 } from "lucide-react"
import { Card } from "@/components/ui/card"

interface VoiceCaptureProps {
  onTaskCreated?: (data: any) => void
}

export default function VoiceCapture({ onTaskCreated }: VoiceCaptureProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error" | "info">("info")
  const [sourceLanguage, setSourceLanguage] = useState("auto")
  const [taskPriority, setTaskPriority] = useState("medium")
  const [transcript, setTranscript] = useState("")
  const recognitionRef = useRef<any>(null)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = sourceLanguage === "auto" ? "en-US" : sourceLanguage

      recognitionRef.current.onstart = () => {
        setIsRecording(true)
        setMessage("Listening... Speak now")
        setMessageType("info")
        setRecordingTime(0)
        setTranscript("")
      }

      recognitionRef.current.onresult = (event: any) => {
        let interim = ""
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript_segment = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            setTranscript((prev) => prev + transcript_segment + " ")
          } else {
            interim += transcript_segment
          }
        }
        if (interim) {
          setMessage(`Interim: ${interim}`)
        }
      }

      recognitionRef.current.onerror = (event: any) => {
        setMessage(`Error: ${event.error}`)
        setMessageType("error")
        setIsRecording(false)
      }

      recognitionRef.current.onend = () => {
        setIsRecording(false)
        if (timerRef.current) clearInterval(timerRef.current)
      }
    } else {
      setMessage("Web Speech API not supported in this browser")
      setMessageType("error")
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [sourceLanguage])

  const startRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.start()
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    }
  }

  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }

  const submitVoiceTask = async () => {
    if (!transcript.trim()) {
      setMessage("Please record something first")
      setMessageType("error")
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/voice-to-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voice_text: transcript,
          source_language: sourceLanguage,
          priority: taskPriority,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create task")
      }

      setMessage(`Task created successfully! ID: ${data.task_id}`)
      setMessageType("success")
      setTranscript("")
      setRecordingTime(0)

      if (onTaskCreated) {
        onTaskCreated(data)
      }

      setTimeout(() => setMessage(""), 5000)
    } catch (error: any) {
      setMessage(`Error: ${error.message}`)
      setMessageType("error")
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4 py-8">
      <Card className="w-full max-w-md p-8 bg-white shadow-2xl rounded-2xl">
        <h1 className="text-3xl font-bold text-center mb-8 text-slate-900">Voice Task Creator</h1>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <div>
            <label htmlFor="language-select" className="block text-sm font-semibold text-slate-700 mb-2">
              Language
            </label>
            <select
              id="language-select"
              value={sourceLanguage}
              onChange={(e) => setSourceLanguage(e.target.value)}
              disabled={isRecording}
              className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg text-sm focus:outline-none focus:border-blue-500 disabled:bg-slate-100"
            >
              <option value="auto">Auto Detect</option>
              <option value="en">English</option>
              <option value="es">Spanish</option>
              <option value="fr">French</option>
              <option value="de">German</option>
              <option value="ja">Japanese</option>
              <option value="zh">Chinese</option>
            </select>
          </div>

          <div>
            <label htmlFor="priority-select" className="block text-sm font-semibold text-slate-700 mb-2">
              Priority
            </label>
            <select
              id="priority-select"
              value={taskPriority}
              onChange={(e) => setTaskPriority(e.target.value)}
              disabled={isRecording}
              className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg text-sm focus:outline-none focus:border-blue-500 disabled:bg-slate-100"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>

        <div className="bg-slate-50 p-6 rounded-xl mb-6">
          <div className="text-center mb-4">
            <p className="text-4xl font-bold text-blue-600">{formatTime(recordingTime)}</p>
            {isRecording && <p className="text-sm text-red-500 font-semibold mt-2 animate-pulse">Recording...</p>}
          </div>

          <div className="flex gap-2">
            <Button
              onClick={isRecording ? stopRecording : startRecording}
              disabled={isLoading}
              variant={isRecording ? "destructive" : "default"}
              className="flex-1"
            >
              {isRecording ? (
                <>
                  <Square className="w-4 h-4 mr-2" />
                  Stop
                </>
              ) : (
                <>
                  <Mic className="w-4 h-4 mr-2" />
                  Start
                </>
              )}
            </Button>
            <Button
              onClick={submitVoiceTask}
              disabled={isLoading || !transcript.trim() || isRecording}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Task"
              )}
            </Button>
            <Button
              onClick={() => {
                setTranscript("")
                setMessage("")
              }}
              disabled={isLoading || isRecording}
              variant="outline"
            >
              Clear
            </Button>
          </div>
        </div>

        <div className="mb-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-2">Transcript</h3>
          <div className="p-4 bg-slate-100 border-2 border-slate-200 rounded-lg min-h-24 text-sm text-slate-700 leading-relaxed">
            {transcript || "(Your speech will appear here)"}
          </div>
        </div>

        {message && (
          <div
            className={`p-3 rounded-lg text-sm font-medium ${
              messageType === "success"
                ? "bg-green-100 text-green-800 border border-green-300"
                : messageType === "error"
                  ? "bg-red-100 text-red-800 border border-red-300"
                  : "bg-blue-100 text-blue-800 border border-blue-300"
            }`}
          >
            {message}
          </div>
        )}
      </Card>
    </div>
  )
}
