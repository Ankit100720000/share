"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, CheckCircle, Clock, Zap } from "lucide-react"

interface Task {
  id: number
  title: string
  description: string
  priority: "low" | "medium" | "high"
  status: "pending" | "in_progress" | "completed" | "cancelled"
  created_at: string
}

interface TaskListProps {
  refreshTrigger?: number
}

export default function TaskList({ refreshTrigger = 0 }: TaskListProps) {
  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("created_at")

  useEffect(() => {
    fetchTasks()
  }, [refreshTrigger])

  const fetchTasks = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/tasks")
      const data = await response.json()
      setTasks(data.tasks || [])
    } catch (error) {
      console.error("Error fetching tasks:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      low: "bg-green-100 text-green-800",
      medium: "bg-yellow-100 text-yellow-800",
      high: "bg-red-100 text-red-800",
    }
    return colors[priority] || "bg-slate-100 text-slate-800"
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case "in_progress":
        return <Zap className="w-4 h-4 text-blue-600" />
      case "pending":
        return <Clock className="w-4 h-4 text-orange-600" />
      default:
        return <AlertCircle className="w-4 h-4 text-slate-400" />
    }
  }

  const filteredTasks = tasks.filter((task) => (filterStatus === "all" ? true : task.status === filterStatus))

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === "created_at") {
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    } else if (sortBy === "priority") {
      const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 }
      return (priorityOrder[a.priority] || 3) - (priorityOrder[b.priority] || 3)
    }
    return 0
  })

  return (
    <div className="py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex justify-between items-center flex-wrap gap-4">
          <h2 className="text-3xl font-bold text-white">Tasks</h2>
          <div className="flex gap-3">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border-2 border-slate-600 bg-slate-800 text-white rounded-lg text-sm focus:outline-none focus:border-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 border-2 border-slate-600 bg-slate-800 text-white rounded-lg text-sm focus:outline-none focus:border-blue-500"
            >
              <option value="created_at">Newest First</option>
              <option value="priority">Priority</option>
            </select>
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-12 text-slate-300">Loading tasks...</div>
        ) : sortedTasks.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No tasks found. Create one with the voice recorder!</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sortedTasks.map((task) => (
              <Card key={task.id} className="bg-slate-800 border-slate-700 p-5 hover:shadow-xl transition-shadow">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-lg font-semibold text-white flex-1 line-clamp-2">{task.title}</h3>
                  <Badge className={`ml-2 ${getPriorityColor(task.priority)} text-xs`}>
                    {task.priority.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-slate-300 text-sm line-clamp-3 mb-4">{task.description}</p>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <div className="flex items-center gap-1">
                    {getStatusIcon(task.status)}
                    <span className="capitalize">{task.status.replace("_", " ")}</span>
                  </div>
                  <span>{new Date(task.created_at).toLocaleDateString()}</span>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
