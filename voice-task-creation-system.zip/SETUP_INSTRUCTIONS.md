# Step-by-Step Setup Instructions

Complete guide to get the Voice-Based Task System running locally.

## System Requirements
- Windows, macOS, or Linux
- Node.js 14+ (https://nodejs.org/)
- MySQL 5.7+ (https://www.mysql.com/downloads/)
- Git (optional, for cloning repository)

## Part 1: MySQL Database Setup (5-10 minutes)

### Step 1: Install MySQL
- Download from https://www.mysql.com/downloads/
- Follow installation wizard
- Remember your root password

### Step 2: Verify MySQL Installation
Open command prompt/terminal and run:
```bash
mysql --version
mysql -u root -p
```
Enter your password. You should see the MySQL prompt `mysql>`.

### Step 3: Create Database
In MySQL terminal, copy and paste:
```sql
CREATE DATABASE voice_task_erp;
USE voice_task_erp;

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE tasks (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT,
  priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
  status ENUM('pending', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
  user_id INT,
  due_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status (status),
  INDEX idx_created_at (created_at),
  INDEX idx_priority (priority)
);

CREATE TABLE voice_recordings (
  id INT PRIMARY KEY AUTO_INCREMENT,
  task_id INT NOT NULL,
  original_text TEXT,
  translated_text LONGTEXT,
  source_language VARCHAR(10),
  target_language VARCHAR(10),
  duration_seconds INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  INDEX idx_task_id (task_id)
);

CREATE TABLE task_activity (
  id INT PRIMARY KEY AUTO_INCREMENT,
  task_id INT NOT NULL,
  user_id INT,
  action VARCHAR(50),
  old_value VARCHAR(255),
  new_value VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_task_id (task_id)
);
```

Type `exit;` to leave MySQL.

## Part 2: Backend Setup (10-15 minutes)

### Step 1: Create Backend Folder
```bash
mkdir voice-task-backend
cd voice-task-backend
```

### Step 2: Initialize Node Project
```bash
npm init -y
```

### Step 3: Install Dependencies
```bash
npm install express cors body-parser helmet express-rate-limit dotenv mysql2 axios
```

### Step 4: Create server.js
Create a file named `server.js` and copy the code from the repository.

### Step 5: Create .env File
Create `.env` file in the same folder:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=voice_task_erp
PORT=5000
FRONTEND_URL=http://localhost:3000
```

Replace `your_mysql_password` with your actual MySQL password.

### Step 6: Start Backend
```bash
node server.js
```

You should see:
```
Server running on port 5000
Frontend URL: http://localhost:3000
```

Keep this terminal window open.

## Part 3: Frontend Setup (10-15 minutes)

### Step 1: Open New Terminal (Keep Backend Running)
Open a new command prompt/terminal window.

### Step 2: Create React App
```bash
npx create-react-app voice-task-frontend
cd voice-task-frontend
```

This takes a few minutes.

### Step 3: Install Axios
```bash
npm install axios
```

### Step 4: Add Components
Create folder: `src/components/`

Create file: `src/components/VoiceCapture.jsx`
Copy code from repository.

Create file: `src/components/VoiceCapture.css`
Copy styles from repository.

Create file: `src/components/TaskList.jsx`
Copy code from repository.

Create file: `src/components/TaskList.css`
Copy styles from repository.

### Step 5: Update App.jsx
Replace `src/App.jsx` with the code from repository.

### Step 6: Update App.css
Replace `src/App.css` with the code from repository.

### Step 7: Create .env File
Create `.env` file in frontend folder:
```env
REACT_APP_API_URL=http://localhost:5000
```

### Step 8: Start Frontend
```bash
npm start
```

Browser will open automatically at `http://localhost:3000`.

## Part 4: Test the System

### Test Voice Recording
1. Click "Start Recording" button
2. Speak clearly into your microphone
3. Click "Stop Recording"
4. Transcript should appear below
5. Click "Create Task"
6. Success message should appear

### Test Task Display
- Scroll down to see "All Tasks" section
- Your created task should appear
- Try filtering by status
- Try sorting by priority

### Test Translation
1. Change "Source Language" to Spanish or French
2. Speak in that language
3. Task should be created with translated text
4. Check console to see original vs translated text

## Troubleshooting During Setup

### Error: "Connection refused" when starting backend
```
Solution:
1. Check MySQL is running
   - Windows: Check Services (services.msc)
   - macOS: Check System Preferences > MySQL
   - Linux: sudo systemctl status mysql
2. Verify DB credentials in .env
3. Test: mysql -u root -p
```

### Error: "EADDRINUSE :::5000"
```
Solution: Port 5000 is already in use
- Change PORT in .env to 5001
- Or kill process: lsof -i :5000 (macOS/Linux)
```

### Error: "Web Speech API not supported"
```
Solution: Use Chrome, Safari, or Edge
Firefox has limited Web Speech support
```

### Error: "CORS error" in browser console
```
Solution:
1. Verify FRONTEND_URL in backend .env
2. Restart backend: Stop and run node server.js again
3. Clear browser cache: Ctrl+Shift+Delete
```

### No tasks appearing in list
```
Solution:
1. Check browser console for errors (F12)
2. Check backend console for database errors
3. Verify .env files have correct URLs
4. Test API: Open http://localhost:5000/api/tasks
```

## Commands Cheat Sheet

**Start Backend:**
```bash
cd backend
node server.js
```

**Start Frontend:**
```bash
cd frontend
npm start
```

**Test Backend Health:**
```bash
curl http://localhost:5000/api/health
```

**View Created Tasks:**
```bash
curl http://localhost:5000/api/tasks
```

**MySQL Commands:**
```bash
mysql -u root -p              # Login to MySQL
SHOW DATABASES;               # List databases
USE voice_task_erp;           # Select database
SHOW TABLES;                  # Show tables
SELECT * FROM tasks;          # View all tasks
```

## Next Steps After Setup

1. **Add More Features**
   - User login/authentication
   - Task editing and deletion
   - Task categories/tags

2. **Improve UI**
   - Add more styling
   - Create dashboard
   - Add notifications

3. **Deploy to Production**
   - Follow DEPLOYMENT section in README.md
   - Use Render.com for backend
   - Use Vercel for frontend

4. **Add Advanced Features**
   - Email notifications
   - Task reminders
   - Team collaboration

---

Congratulations! You have successfully set up the Voice-Based Task System!
