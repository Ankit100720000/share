-- Insert sample data for testing
INSERT INTO users (username, email, password_hash, full_name) VALUES
('john_doe', 'john@example.com', 'hashed_password_1', 'John Doe'),
('jane_smith', 'jane@example.com', 'hashed_password_2', 'Jane Smith');

INSERT INTO tasks (title, description, priority, status, user_id, due_date) VALUES
('Complete project documentation', 'Write comprehensive documentation for the voice task system', 'high', 'in_progress', 1, '2024-12-31'),
('Review code changes', 'Review and approve pull requests from team members', 'medium', 'pending', 2, NULL),
('Fix bug in voice recording', 'Audio cuts off after 30 seconds', 'high', 'pending', 1, '2024-12-20');
