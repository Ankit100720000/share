# Voice-Based Task Creation System (ERP Feature)

A complete full-stack ERP feature that allows users to create tasks using voice commands. Convert speech to text, translate it automatically, and save tasks to a MySQL database.

## Table of Contents
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Architecture](#project-architecture)
- [Setup Guide](#setup-guide)
- [API Documentation](#api-documentation)
- [Security Best Practices](#security-best-practices)
- [Testing Plan](#testing-plan)
- [Deployment Guide](#deployment-guide)

## Features

✅ **Voice Recording**: Browser Web Speech API (no external API required)
✅ **Multi-Language Support**: Auto-detect or select language
✅ **Translation**: Free LibreTranslate API for multi-language support
✅ **Task Priority**: Low, Medium, High
✅ **Task Status**: Pending, In Progress, Completed, Cancelled
✅ **Real-time UI Updates**: Immediate feedback on recording and task creation
✅ **Task Filtering & Sorting**: Filter by status, sort by priority or date
✅ **Voice Recording History**: Track original text and translated text

## Tech Stack

| Component | Technology |
|-----------|------------|
| Frontend | React.js + Axios |
| Backend | Node.js + Express.js |
| Database | MySQL 5.7+ |
| Voice API | Browser Web Speech API (Free) |
| Translation | LibreTranslate API (Free) |
| Security | Helmet, CORS, Rate Limiting |
| Authentication | JWT (optional, for future) |

## Project Architecture

```
voice-task-erp/
├── backend/
│   ├── server.js                 # Express server, main entry
│   ├── package.json              # Backend dependencies
│   ├── .env                      # Environment variables
│   └── database/
│       ├── schema.sql            # MySQL table creation
│       └── seed.sql              # Sample data
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   ├── VoiceCapture.jsx  # Voice recording component
│   │   │   ├── VoiceCapture.css  # Voice capture styles
│   │   │   ├── TaskList.jsx      # Task display component
│   │   │   └── TaskList.css      # Task list styles
│   │   ├── App.jsx               # Main app component
│   │   ├── App.css               # App styles
│   │   └── index.js              # React entry point
│   ├── .env                      # Frontend environment variables
│   └── package.json              # Frontend dependencies
│
└── README.md                      # This file
```

## Setup Guide

### Prerequisites
- Node.js 14+ and npm
- MySQL 5.7 or higher
- A modern web browser with Web Speech API support (Chrome, Edge, Safari)

### Backend Setup

1. **Install Dependencies**
```bash
cd backend
npm install
```

Required packages:
```json
{
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "body-parser": "^1.20.2",
    "helmet": "^7.0.0",
    "express-rate-limit": "^6.7.0",
    "dotenv": "^16.0.3",
    "mysql2": "^3.3.5",
    "axios": "^1.4.0"
  }
}
```

2. **Setup MySQL Database**
```bash
# Login to MySQL
mysql -u root -p

# Run the schema script
source database/schema.sql

# (Optional) Load sample data
source database/seed.sql
```

3. **Configure Environment Variables**
Create `.env` file in backend folder:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=voice_task_erp
PORT=5000
FRONTEND_URL=http://localhost:3000
```

4. **Start Backend Server**
```bash
npm start
# or
node server.js
```
Server will run on `http://localhost:5000`

### Frontend Setup

1. **Create React App**
```bash
npx create-react-app frontend
cd frontend
```

2. **Install Dependencies**
```bash
npm install axios
```

3. **Copy Components**
Copy `VoiceCapture.jsx`, `TaskList.jsx` and their CSS files to `src/components/`

4. **Configure Environment**
Create `.env` file in frontend folder:
```env
REACT_APP_API_URL=http://localhost:5000
```

5. **Start Frontend**
```bash
npm start
```
App will run on `http://localhost:3000`

## API Documentation

### Base URL
```
http://localhost:5000/api
```

### Endpoints

#### 1. **Health Check**
```
GET /api/health
```
**Response:**
```json
{
  "status": "Backend is running",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

#### 2. **Translate Text**
```
POST /api/translate
```
**Request Body:**
```json
{
  "text": "Hola, necesito crear una tarea",
  "source_language": "es",
  "target_language": "en"
}
```
**Response:**
```json
{
  "original_text": "Hola, necesito crear una tarea",
  "translated_text": "Hello, I need to create a task",
  "source_language": "es",
  "target_language": "en"
}
```

#### 3. **Create Task**
```
POST /api/tasks
```
**Request Body:**
```json
{
  "title": "Complete project documentation",
  "description": "Write comprehensive documentation",
  "priority": "high",
  "due_date": "2024-12-31"
}
```
**Response:**
```json
{
  "success": true,
  "message": "Task created successfully",
  "task_id": 1,
  "task": {
    "id": 1,
    "title": "Complete project documentation",
    "description": "Write comprehensive documentation",
    "priority": "high",
    "due_date": "2024-12-31",
    "status": "pending",
    "created_at": "2024-01-15T10:30:00Z"
  }
}
```

#### 4. **Get All Tasks**
```
GET /api/tasks
```
**Response:**
```json
{
  "success": true,
  "count": 3,
  "tasks": [
    {
      "id": 1,
      "title": "Task Title",
      "description": "Description",
      "priority": "high",
      "status": "pending",
      "user_id": null,
      "due_date": null,
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T10:30:00Z"
    }
  ]
}
```

#### 5. **Voice to Task (Combined)**
```
POST /api/voice-to-task
```
**Request Body:**
```json
{
  "voice_text": "Buy groceries and prepare dinner",
  "source_language": "en",
  "priority": "medium"
}
```
**Response:**
```json
{
  "success": true,
  "message": "Task created from voice successfully",
  "original_text": "Buy groceries and prepare dinner",
  "translated_text": "Buy groceries and prepare dinner",
  "task_id": 5,
  "priority": "medium"
}
```

## Security Best Practices

### 1. **Helmet.js**
- Sets HTTP security headers
- Prevents XSS, clickjacking attacks
- Enabled in Express middleware

### 2. **CORS Configuration**
- Whitelist frontend domain
- Disable credentials by default
- Only allow necessary methods

```javascript
cors({
  origin: process.env.FRONTEND_URL,
  credentials: true,
  optionsSuccessStatus: 200
})
```

### 3. **Rate Limiting**
- 100 requests per 15 minutes per IP
- Prevents brute force attacks
- Enabled on all routes

### 4. **Input Validation**
- Trim and validate text inputs
- Check for empty strings
- Validate enum values (priority, status)

### 5. **SQL Injection Prevention**
- Use parameterized queries
- Mysql2 automatically escapes values

```javascript
const query = "INSERT INTO tasks (title) VALUES (?)"
await connection.execute(query, [userInput]) // Safe!
```

### 6. **Error Handling**
- Never expose database errors to client
- Generic error messages in responses
- Detailed logging on server

### 7. **Environment Variables**
- Store sensitive data in `.env`
- Never commit `.env` to git
- Add to `.gitignore`

### 8. **HTTPS in Production**
- Use HTTPS for all communication
- Use secure cookies
- Implement HSTS

## Testing Plan

### Unit Tests

#### Backend Tests
```bash
npm install --save-dev jest supertest
```

Test files:
- `tests/api.test.js` - API endpoint tests
- `tests/translation.test.js` - Translation service tests
- `tests/database.test.js` - Database operations

Example test:
```javascript
describe('POST /api/tasks', () => {
  it('should create a task with valid input', async () => {
    const response = await request(app)
      .post('/api/tasks')
      .send({
        title: 'Test Task',
        priority: 'high'
      })
    
    expect(response.status).toBe(201)
    expect(response.body.success).toBe(true)
    expect(response.body.task_id).toBeDefined()
  })

  it('should reject task without title', async () => {
    const response = await request(app)
      .post('/api/tasks')
      .send({ priority: 'high' })
    
    expect(response.status).toBe(400)
  })
})
```

#### Frontend Tests
```bash
npm install --save-dev @testing-library/react @testing-library/jest-dom
```

Test voice capture component:
```javascript
test('VoiceCapture starts recording on button click', () => {
  const { getByText } = render(<VoiceCapture />)
  const startBtn = getByText('Start Recording')
  fireEvent.click(startBtn)
  expect(getByText('Stop Recording')).toBeInTheDocument()
})
```

### Manual Testing Checklist

- [ ] Voice recording works in Chrome/Safari
- [ ] Transcript appears in real-time
- [ ] Task created successfully
- [ ] Language selection works
- [ ] Priority selection works
- [ ] Tasks display in list
- [ ] Filter by status works
- [ ] Sort by priority works
- [ ] Error messages display correctly
- [ ] Rate limiting works (send 150 requests)
- [ ] CORS works for frontend domain

### Browser Compatibility
- Chrome 25+
- Firefox 47+
- Safari 14.1+
- Edge 79+

**Note**: Internet Explorer does not support Web Speech API

## Deployment Guide

### Deploy Backend to Render.com (Free)

1. **Create GitHub Repository**
```bash
git init
git add .
git commit -m "Initial commit"
git push origin main
```

2. **Sign Up on Render.com**
- Visit https://render.com
- Sign up with GitHub
- Create New Service

3. **Create Web Service**
- Connect GitHub repository
- Set Runtime: Node
- Build Command: `npm install`
- Start Command: `node server.js`
- Add environment variables in Render dashboard

4. **Setup MySQL Database**
Option A: Use Render's PostgreSQL (not MySQL)
Option B: Use free MySQL host like:
- Clever Cloud (free tier available)
- db4free.net
- Update DB_HOST in environment variables

5. **Deploy**
- Push to GitHub and Render auto-deploys
- Backend URL: `https://your-app.onrender.com`

### Deploy Frontend to Vercel (Free)

1. **Build React App**
```bash
npm run build
```

2. **Sign Up on Vercel.com**
- Visit https://vercel.com
- Sign up with GitHub

3. **Import Project**
- Select your GitHub repository
- Vercel auto-detects React app
- Add environment variable:
```
REACT_APP_API_URL=https://your-app.onrender.com
```

4. **Deploy**
- Vercel auto-deploys on git push
- Frontend URL: `https://your-app.vercel.app`

### Alternative: Deploy Both to Railway.app

1. **Sign up at https://railway.app**

2. **Create Two Projects**
   - One for Node backend
   - One for React frontend (uses Node to serve build)

3. **Add Services**
   - Connect GitHub repos
   - Configure environment variables
   - Railway deploys automatically

## Troubleshooting

### Web Speech API Not Available
- Use Chrome, Safari, or Edge
- Firefox has limited support
- Check browser console for errors

### Translation API Offline
- LibreTranslate service may be down
- Tasks will be created with original text
- Alternative: Use Google Translate API (requires API key)

### Database Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:3306

Solution:
- Check MySQL is running
- Verify credentials in .env
- Ensure database exists: CREATE DATABASE voice_task_erp;
```

### CORS Error
```
Access to XMLHttpRequest blocked by CORS policy

Solution:
- Verify FRONTEND_URL in backend .env
- Ensure frontend URL matches exactly
- Check Access-Control-Allow-Origin headers
```

### Rate Limiting Error
```
Too many requests, please try again later

Solution:
- Wait 15 minutes or reduce request frequency
- Change windowMs in rate limiter for testing
- Disable rate limiting in development: remove limiter middleware
```

## Future Enhancements

- [ ] User authentication (JWT/OAuth)
- [ ] Task assignment to team members
- [ ] Task categories/tags
- [ ] Recurring tasks
- [ ] Task attachments
- [ ] Email notifications
- [ ] Mobile app (React Native)
- [ ] Advanced analytics
- [ ] Task templates
- [ ] Integration with calendar apps

## License

MIT License - Free to use and modify

## Support

For issues, questions, or suggestions:
1. Check Troubleshooting section
2. Review API Documentation
3. Test with Postman/Thunder Client
4. Check browser console for errors

---

**Happy Voice Task Creating!**
