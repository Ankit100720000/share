# Voice-Based Task Creation System - Next.js Setup

This is a complete voice-to-task ERP feature integrated into Next.js with TypeScript and Tailwind CSS.

## Features

✅ Voice Recording using Web Speech API (free, no external APIs required)
✅ Real-time Transcript Display
✅ Multi-Language Support (auto-detect or manual selection)
✅ Task Priority (Low, Medium, High)
✅ Task Management (filter and sort)
✅ Translation Support (uses free LibreTranslate API)

## Project Structure

```
app/
├── page.tsx                     # Home page with voice capture & task list
├── api/
│   ├── voice-to-task/route.ts  # API endpoint for voice-to-task conversion
│   └── tasks/route.ts          # API endpoints for task management
components/
├── voice-capture.tsx            # Voice recording component
├── task-list.tsx               # Task display component
├── ui/                         # Shadcn UI components (already included)
```

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Modern web browser with Web Speech API support (Chrome, Safari, Edge)

### Installation

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Run Development Server**
   ```bash
   npm run dev
   ```

3. **Open in Browser**
   Navigate to `http://localhost:3000`

## Usage

### Record a Voice Task

1. Click the **"Start Recording"** button
2. Speak clearly into your microphone
3. Click **"Stop Recording"** when finished
4. Transcript will appear in the box below
5. Select language (optional, auto-detect is default)
6. Select priority (Low, Medium, High)
7. Click **"Create Task"**
8. Task appears in the list below

### Manage Tasks

- **Filter by Status**: Select from "All Status", "Pending", "In Progress", "Completed", "Cancelled"
- **Sort Tasks**: Sort by "Newest First" or "Priority"
- **View Task Details**: Each task card shows title, description, priority badge, status, and date

## API Endpoints

### POST /api/voice-to-task
Create a task from voice text.

**Request:**
```json
{
  "voice_text": "Buy groceries for dinner",
  "source_language": "en",
  "priority": "medium"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Task created from voice successfully",
  "original_text": "Buy groceries for dinner",
  "translated_text": "Buy groceries for dinner",
  "task_id": 2,
  "priority": "medium"
}
```

### GET /api/tasks
Retrieve all tasks.

**Response:**
```json
{
  "success": true,
  "count": 2,
  "tasks": [
    {
      "id": 1,
      "title": "Example Task",
      "description": "...",
      "priority": "medium",
      "status": "pending",
      "created_at": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

### POST /api/tasks
Create a task directly.

**Request:**
```json
{
  "title": "Task title",
  "description": "Optional description",
  "priority": "high"
}
```

## Browser Compatibility

| Browser | Support | Version |
|---------|---------|---------|
| Chrome  | ✅ Full | 25+     |
| Safari  | ✅ Full | 14.1+   |
| Edge    | ✅ Full | 79+     |
| Firefox | ⚠️ Limited | 47+   |
| IE      | ❌ Not supported | - |

## Troubleshooting

### "Web Speech API not supported"
- Use Chrome, Safari, or Edge browser
- Firefox has limited support
- Check browser console (F12) for errors

### No microphone access
- Check browser permissions for microphone
- Ensure `https://` in production (required for Web Speech API)
- Reset microphone permissions in browser settings

### Translation not working
- LibreTranslate API may be temporarily down
- Tasks will be created with original text
- Check browser console for API errors

### Tasks not appearing
- Refresh the page
- Check browser developer console (F12)
- Ensure POST request completed successfully

## Production Deployment

### Database Setup (Optional)

For production, integrate with a real database:

1. **Connect to Supabase, Neon, or PostgreSQL**
2. **Replace mock storage** in API routes
3. **Add environment variables**:
   ```env
   DATABASE_URL=your_database_url
   ```

### Example with PostgreSQL:

```typescript
// app/api/voice-to-task/route.ts
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  const body = await request.json()
  
  const task = await db.task.create({
    data: {
      title: body.voice_text.substring(0, 100),
      description: body.voice_text,
      priority: body.priority,
      status: 'pending'
    }
  })
  
  return NextResponse.json({ success: true, task_id: task.id }, { status: 201 })
}
```

## Future Enhancements

- [ ] User authentication
- [ ] Task categories/tags
- [ ] Email notifications
- [ ] Recurring tasks
- [ ] Task attachments
- [ ] Team collaboration
- [ ] Mobile app
- [ ] Advanced analytics

## License

MIT - Free to use and modify

---

**Enjoy building with the Voice Task System!**
