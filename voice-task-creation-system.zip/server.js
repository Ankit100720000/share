import express from "express"
import cors from "cors"
import bodyParser from "body-parser"
import helmet from "helmet"
import rateLimit from "express-rate-limit"
import dotenv from "dotenv"
import { createPool } from "mysql2/promise"
import axios from "axios"

dotenv.config()

const app = express()

// Middleware
app.use(helmet())
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    credentials: true,
  }),
)
app.use(bodyParser.json({ limit: "10mb" }))
app.use(bodyParser.urlencoded({ limit: "10mb", extended: true }))

// Rate limiting to prevent abuse
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: "Too many requests, please try again later",
})
app.use(limiter)

// MySQL Pool
const pool = createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "voice_task_erp",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "Backend is running", timestamp: new Date() })
})

// Translate text using LibreTranslate API (free)
app.post("/api/translate", async (req, res) => {
  try {
    const { text, source_language = "auto", target_language = "en" } = req.body

    if (!text || text.trim().length === 0) {
      return res.status(400).json({ error: "Text is required" })
    }

    // Call LibreTranslate API
    const response = await axios.post("https://libretranslate.de/translate", {
      q: text,
      source_language: source_language,
      target_language: target_language,
    })

    res.json({
      original_text: text,
      translated_text: response.data.translatedText,
      source_language: source_language,
      target_language: target_language,
    })
  } catch (error) {
    console.error("Translation error:", error.message)
    res.status(500).json({ error: "Translation failed", message: error.message })
  }
})

// Create task endpoint
app.post("/api/tasks", async (req, res) => {
  const connection = await pool.getConnection()
  try {
    const { title, description, priority = "medium", due_date = null } = req.body

    if (!title || title.trim().length === 0) {
      return res.status(400).json({ error: "Task title is required" })
    }

    const query =
      "INSERT INTO tasks (title, description, priority, due_date, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())"
    const values = [title.trim(), description || "", priority, due_date]

    const [result] = await connection.execute(query, values)

    res.status(201).json({
      success: true,
      message: "Task created successfully",
      task_id: result.insertId,
      task: {
        id: result.insertId,
        title: title,
        description: description || "",
        priority: priority,
        due_date: due_date,
        status: "pending",
        created_at: new Date(),
      },
    })
  } catch (error) {
    console.error("Error creating task:", error.message)
    res.status(500).json({ error: "Failed to create task", message: error.message })
  } finally {
    connection.release()
  }
})

// Get all tasks endpoint
app.get("/api/tasks", async (req, res) => {
  const connection = await pool.getConnection()
  try {
    const [tasks] = await connection.execute("SELECT * FROM tasks ORDER BY created_at DESC LIMIT 100")
    res.json({
      success: true,
      count: tasks.length,
      tasks: tasks,
    })
  } catch (error) {
    console.error("Error fetching tasks:", error.message)
    res.status(500).json({ error: "Failed to fetch tasks", message: error.message })
  } finally {
    connection.release()
  }
})

// Voice to task endpoint (combines voice text + translation + task creation)
app.post("/api/voice-to-task", async (req, res) => {
  const connection = await pool.getConnection()
  try {
    const { voice_text, source_language = "auto", priority = "medium" } = req.body

    if (!voice_text || voice_text.trim().length === 0) {
      return res.status(400).json({ error: "Voice text is required" })
    }

    // Translate the voice text
    let translatedText = voice_text
    if (source_language !== "en") {
      try {
        const translationResponse = await axios.post("https://libretranslate.de/translate", {
          q: voice_text,
          source_language: source_language,
          target_language: "en",
        })
        translatedText = translationResponse.data.translatedText
      } catch (error) {
        console.warn("Translation failed, using original text:", error.message)
      }
    }

    // Create task with translated text
    const taskTitle = translatedText.substring(0, 100) // First 100 chars as title
    const query = "INSERT INTO tasks (title, description, priority, status, created_at) VALUES (?, ?, ?, ?, NOW())"
    const values = [taskTitle, translatedText, priority, "pending"]

    const [result] = await connection.execute(query, values)

    res.status(201).json({
      success: true,
      message: "Task created from voice successfully",
      original_text: voice_text,
      translated_text: translatedText,
      task_id: result.insertId,
      priority: priority,
    })
  } catch (error) {
    console.error("Error in voice-to-task:", error.message)
    res.status(500).json({ error: "Failed to process voice task", message: error.message })
  } finally {
    connection.release()
  }
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Server error:", err)
  res.status(500).json({ error: "Internal server error", message: err.message })
})

// Start server
const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
  console.log(`Frontend URL: ${process.env.FRONTEND_URL || "http://localhost:3000"}`)
})
