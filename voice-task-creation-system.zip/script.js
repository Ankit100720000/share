// Speech Recognition Setup
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
const recognition = new SpeechRecognition()

// DOM Elements
const voiceBtn = document.getElementById("voiceBtn")
const textInput = document.getElementById("textInput")
const voiceStatus = document.getElementById("voiceStatus")
const languageSelect = document.getElementById("language")
const clearBtn = document.getElementById("clearBtn")

// Voice Recognition Configuration
recognition.continuous = false
recognition.interimResults = true
recognition.lang = "en-US"

// Voice Recognition Events
recognition.onstart = () => {
  voiceBtn.classList.add("recording")
  voiceBtn.innerHTML = '<i class="bi bi-mic-fill"></i>'
  voiceStatus.textContent = "🎤 Listening..."
  voiceStatus.classList.add("listening")
}

recognition.onresult = (event) => {
  let interimTranscript = ""
  for (let i = event.resultIndex; i < event.results.length; i++) {
    const transcript = event.results[i].transcript
    if (event.results[i].isFinal) {
      textInput.value += (textInput.value ? " " : "") + transcript
    } else {
      interimTranscript += transcript
    }
  }
  if (interimTranscript) {
    voiceStatus.textContent = `Heard: "${interimTranscript}"`
  }
}

recognition.onerror = (event) => {
  voiceStatus.textContent = `Error: ${event.error}`
  console.error("Speech recognition error:", event.error)
}

recognition.onend = () => {
  voiceBtn.classList.remove("recording")
  voiceBtn.innerHTML = '<i class="bi bi-mic"></i>'
  voiceStatus.classList.remove("listening")
  voiceStatus.textContent = ""
}

// Voice Button Click Handler
voiceBtn.addEventListener("click", () => {
  if (recognition.isListening) {
    recognition.abort()
    recognition.isListening = false
  } else {
    recognition.lang = languageSelect.value
    recognition.start()
    recognition.isListening = true
  }
})

// Language Change Handler
languageSelect.addEventListener("change", () => {
  recognition.lang = languageSelect.value
})

// Clear Button Handler
clearBtn.addEventListener("click", () => {
  textInput.value = ""
  voiceStatus.textContent = ""
  textInput.focus()
})
