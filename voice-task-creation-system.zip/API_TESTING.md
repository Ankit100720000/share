# API Testing Guide

Test all backend APIs using Postman or cURL.

## Download Postman
1. Visit https://www.postman.com/downloads/
2. Download and install
3. Create free account

## Test Endpoints

### 1. Health Check
**GET** `http://localhost:5000/api/health`

**cURL:**
```bash
curl http://localhost:5000/api/health
```

**Expected Response (200):**
```json
{
  "status": "Backend is running",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 2. Create Task
**POST** `http://localhost:5000/api/tasks`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "title": "Buy groceries",
  "description": "Buy milk, eggs, and bread from the store",
  "priority": "high",
  "due_date": "2024-12-31"
}
```

**cURL:**
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Buy groceries",
    "priority": "high"
  }'
```

**Expected Response (201):**
```json
{
  "success": true,
  "message": "Task created successfully",
  "task_id": 1,
  "task": {
    "id": 1,
    "title": "Buy groceries",
    "description": "Buy milk, eggs, and bread from the store",
    "priority": "high",
    "due_date": "2024-12-31",
    "status": "pending",
    "created_at": "2024-01-15T10:30:00.000Z"
  }
}
```

### 3. Get All Tasks
**GET** `http://localhost:5000/api/tasks`

**cURL:**
```bash
curl http://localhost:5000/api/tasks
```

**Expected Response (200):**
```json
{
  "success": true,
  "count": 3,
  "tasks": [
    {
      "id": 1,
      "title": "Buy groceries",
      "description": "Buy milk, eggs, and bread",
      "priority": "high",
      "status": "pending",
      "user_id": null,
      "due_date": "2024-12-31",
      "created_at": "2024-01-15T10:30:00.000Z",
      "updated_at": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

### 4. Translate Text
**POST** `http://localhost:5000/api/translate`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "text": "Hola, me gustaría crear una tarea",
  "source_language": "es",
  "target_language": "en"
}
```

**cURL:**
```bash
curl -X POST http://localhost:5000/api/translate \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Hola, me gustaría crear una tarea",
    "source_language": "es",
    "target_language": "en"
  }'
```

**Expected Response (200):**
```json
{
  "original_text": "Hola, me gustaría crear una tarea",
  "translated_text": "Hello, I would like to create a task",
  "source_language": "es",
  "target_language": "en"
}
```

### 5. Voice to Task (Complete Flow)
**POST** `http://localhost:5000/api/voice-to-task`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "voice_text": "Call the client at 3 PM tomorrow",
  "source_language": "en",
  "priority": "high"
}
```

**cURL:**
```bash
curl -X POST http://localhost:5000/api/voice-to-task \
  -H "Content-Type: application/json" \
  -d '{
    "voice_text": "Call the client at 3 PM tomorrow",
    "source_language": "en",
    "priority": "high"
  }'
```

**Expected Response (201):**
```json
{
  "success": true,
  "message": "Task created from voice successfully",
  "original_text": "Call the client at 3 PM tomorrow",
  "translated_text": "Call the client at 3 PM tomorrow",
  "task_id": 5,
  "priority": "high"
}
```

## Error Testing

### Test Missing Field
**POST** `http://localhost:5000/api/tasks`

**Body (missing title):**
```json
{
  "priority": "high"
}
```

**Expected Response (400):**
```json
{
  "error": "Task title is required"
}
```

### Test Invalid Priority
**POST** `http://localhost:5000/api/tasks`

**Body (invalid priority):**
```json
{
  "title": "Test",
  "priority": "invalid"
}
```

Backend will accept it, but should validate in production.

### Test Rate Limiting
Send 101 requests in 15 minutes window.

**Expected Response (429):**
```json
{
  "error": "Too many requests, please try again later"
}
```

## Load Testing

### Test with Multiple Tasks
```bash
for i in {1..50}; do
  curl -X POST http://localhost:5000/api/tasks \
    -H "Content-Type: application/json" \
    -d "{\"title\": \"Task $i\", \"priority\": \"medium\"}"
  sleep 0.1
done
```

Then verify: `curl http://localhost:5000/api/tasks`

## Performance Notes

- **Response Time**: Should be < 100ms
- **Database**: Indexes on status, priority, created_at
- **Rate Limit**: 100 requests per 15 minutes
- **Max Tasks**: Limited by MySQL (tested up to 1M rows)

---

Use this guide to verify all APIs work correctly!
