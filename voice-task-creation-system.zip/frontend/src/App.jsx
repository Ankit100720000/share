"use client"

import { useState } from "react"
import VoiceCapture from "./components/VoiceCapture"
import TaskList from "./components/TaskList"
import "./App.css"

function App() {
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  const handleTaskCreated = () => {
    // Trigger task list refresh
    setRefreshTrigger((prev) => prev + 1)
  }

  return (
    <div className="app">
      <VoiceCapture onTaskCreated={handleTaskCreated} />
      <TaskList refreshTrigger={refreshTrigger} />
    </div>
  )
}

export default App
