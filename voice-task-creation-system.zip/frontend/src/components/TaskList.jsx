"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import "./TaskList.css"

const TaskList = ({ refreshTrigger }) => {
  const [tasks, setTasks] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("created_at")

  useEffect(() => {
    fetchTasks()
  }, [refreshTrigger])

  const fetchTasks = async () => {
    setIsLoading(true)
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/tasks`)
      setTasks(response.data.tasks || [])
    } catch (error) {
      console.error("Error fetching tasks:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const updateTaskStatus = async (taskId, newStatus) => {
    try {
      // This would require an UPDATE endpoint in your backend
      console.log(`Updating task ${taskId} to ${newStatus}`)
      // For now, update locally
      setTasks((prevTasks) => prevTasks.map((task) => (task.id === taskId ? { ...task, status: newStatus } : task)))
    } catch (error) {
      console.error("Error updating task:", error)
    }
  }

  const getPriorityColor = (priority) => {
    const colors = {
      low: "#2ed573",
      medium: "#ffa502",
      high: "#ff4757",
    }
    return colors[priority] || "#667eea"
  }

  const getStatusColor = (status) => {
    const colors = {
      pending: "#ffa502",
      in_progress: "#2196f3",
      completed: "#2ed573",
      cancelled: "#9ca3af",
    }
    return colors[status] || "#667eea"
  }

  const filteredTasks = tasks.filter((task) => (filterStatus === "all" ? true : task.status === filterStatus))

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === "created_at") {
      return new Date(b.created_at) - new Date(a.created_at)
    } else if (sortBy === "priority") {
      const priorityOrder = { high: 0, medium: 1, low: 2 }
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    }
    return 0
  })

  return (
    <div className="task-list-container">
      <div className="task-list-header">
        <h2>All Tasks</h2>
        <div className="filters">
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="filter-select">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="filter-select">
            <option value="created_at">Newest First</option>
            <option value="priority">Priority</option>
          </select>
        </div>
      </div>

      {isLoading ? (
        <div className="loading">Loading tasks...</div>
      ) : sortedTasks.length === 0 ? (
        <div className="no-tasks">No tasks found. Create one with the voice recorder!</div>
      ) : (
        <div className="tasks-grid">
          {sortedTasks.map((task) => (
            <div key={task.id} className="task-card">
              <div className="task-header">
                <h3>{task.title}</h3>
                <span className="priority-badge" style={{ backgroundColor: getPriorityColor(task.priority) }}>
                  {task.priority.toUpperCase()}
                </span>
              </div>
              <p className="task-description">{task.description}</p>
              <div className="task-footer">
                <select
                  value={task.status}
                  onChange={(e) => updateTaskStatus(task.id, e.target.value)}
                  className="status-select"
                  style={{ borderColor: getStatusColor(task.status) }}
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
                <span className="task-date">{new Date(task.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default TaskList
