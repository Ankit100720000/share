"use client"

import React, { useState, useRef } from "react"
import axios from "axios"
import "./VoiceCapture.css"

const VoiceCapture = ({ onTaskCreated }) => {
  const [isRecording, setIsRecording] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState("") // 'success', 'error', 'info'
  const recognitionRef = useRef(null)
  const timerRef = useRef(null)
  const [sourceLanguage, setSourceLanguage] = useState("auto")
  const [taskPriority, setTaskPriority] = useState("medium")
  const [transcript, setTranscript] = useState("")

  // Initialize Web Speech API
  React.useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = sourceLanguage === "auto" ? "en-US" : sourceLanguage

      recognitionRef.current.onstart = () => {
        setIsRecording(true)
        setMessage("Listening... Speak now")
        setMessageType("info")
        setRecordingTime(0)
        setTranscript("")
      }

      recognitionRef.current.onresult = (event) => {
        let interim = ""
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript_segment = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            setTranscript((prev) => prev + transcript_segment + " ")
          } else {
            interim += transcript_segment
          }
        }
        // Display interim results
        if (interim) {
          setMessage(`Interim: ${interim}`)
        }
      }

      recognitionRef.current.onerror = (event) => {
        setMessage(`Error: ${event.error}`)
        setMessageType("error")
        setIsRecording(false)
      }

      recognitionRef.current.onend = () => {
        setIsRecording(false)
        clearInterval(timerRef.current)
      }
    } else {
      setMessage("Web Speech API not supported in this browser")
      setMessageType("error")
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
      clearInterval(timerRef.current)
    }
  }, [sourceLanguage])

  // Start recording
  const startRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.start()
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    }
  }

  // Stop recording
  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
      clearInterval(timerRef.current)
    }
  }

  // Send voice text to backend
  const submitVoiceTask = async () => {
    if (!transcript.trim()) {
      setMessage("Please record something first")
      setMessageType("error")
      return
    }

    setIsLoading(true)
    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/voice-to-task`, {
        voice_text: transcript,
        source_language: sourceLanguage,
        priority: taskPriority,
      })

      setMessage(`Task created successfully! ID: ${response.data.task_id}`)
      setMessageType("success")
      setTranscript("")
      setRecordingTime(0)

      // Call callback to refresh task list
      if (onTaskCreated) {
        onTaskCreated(response.data)
      }

      // Clear message after 5 seconds
      setTimeout(() => setMessage(""), 5000)
    } catch (error) {
      const errorMsg = error.response?.data?.message || error.message
      setMessage(`Error creating task: ${errorMsg}`)
      setMessageType("error")
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  return (
    <div className="voice-capture-container">
      <div className="voice-capture-card">
        <h1>Voice-Based Task Creation</h1>

        <div className="settings-section">
          <div className="setting-group">
            <label htmlFor="language-select">Source Language</label>
            <select
              id="language-select"
              value={sourceLanguage}
              onChange={(e) => setSourceLanguage(e.target.value)}
              disabled={isRecording}
            >
              <option value="auto">Auto Detect</option>
              <option value="en">English</option>
              <option value="es">Spanish</option>
              <option value="fr">French</option>
              <option value="de">German</option>
              <option value="it">Italian</option>
              <option value="pt">Portuguese</option>
              <option value="ja">Japanese</option>
              <option value="zh">Chinese</option>
            </select>
          </div>

          <div className="setting-group">
            <label htmlFor="priority-select">Task Priority</label>
            <select
              id="priority-select"
              value={taskPriority}
              onChange={(e) => setTaskPriority(e.target.value)}
              disabled={isRecording}
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>

        <div className="recorder-section">
          <div className="recording-display">
            <p className="recording-time">{formatTime(recordingTime)}</p>
            {isRecording && <div className="recording-indicator">Recording...</div>}
          </div>

          <div className="button-group">
            <button
              className={`btn btn-primary ${isRecording ? "btn-stop" : "btn-start"}`}
              onClick={isRecording ? stopRecording : startRecording}
              disabled={isLoading}
            >
              {isRecording ? "Stop Recording" : "Start Recording"}
            </button>
            <button
              className="btn btn-success"
              onClick={submitVoiceTask}
              disabled={isLoading || !transcript.trim() || isRecording}
            >
              {isLoading ? "Creating Task..." : "Create Task"}
            </button>
            <button
              className="btn btn-secondary"
              onClick={() => {
                setTranscript("")
                setMessage("")
              }}
              disabled={isLoading || isRecording}
            >
              Clear
            </button>
          </div>
        </div>

        <div className="transcript-section">
          <h3>Transcript</h3>
          <div className="transcript-box">{transcript || "(Your speech will appear here)"}</div>
        </div>

        {message && <div className={`message message-${messageType}`}>{message}</div>}
      </div>
    </div>
  )
}

export default VoiceCapture
